import express from 'express';
import { getInsights, getPredictions } from '../controllers/aiController.js';
import auth from '../middleware/auth.js';

const router = express.Router();

// All routes are protected
router.get('/insights', auth, getInsights);
router.get('/predictions', auth, getPredictions);

export default router; 