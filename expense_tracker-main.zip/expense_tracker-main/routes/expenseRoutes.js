import express from 'express';
import auth from '../middleware/auth.js';
import { 
  addExpense, 
  getExpenses, 
  getExpense, 
  updateExpense, 
  deleteExpense,
  getExpenseStats 
} from '../controllers/expenseController.js';
import { getInsights } from '../controllers/aiController.js';

const router = express.Router();

// Protected routes
router.use(auth);

// CRUD routes
router.route('/')
  .post(addExpense)
  .get(getExpenses);

router.route('/stats')
  .get(getExpenseStats);

router.route('/insights')
  .get(getInsights);

router.route('/:id')
  .get(getExpense)
  .put(updateExpense)
  .delete(deleteExpense);

export default router; 