import User from '../models/User.js';
import jwt from 'jsonwebtoken';

export const register = async (req, res) => {
  try {
    console.log('Registration request body:', req.body);
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    // Check if user already exists
    let user = await User.findOne({ username });
    if (user) {
      return res.status(400).json({ message: 'User already exists' });
    }

    // Create new user
    user = new User({
      username,
      password
    });

    await user.save();
    console.log('New user created:', username);

    // Create JWT token
    const token = jwt.sign(
      { userId: user._id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      token,
      user: {
        id: user._id,
        username: user.username
      }
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const login = async (req, res) => {
  try {
    console.log('Login request body:', req.body);
    const { username, password } = req.body;

    if (!username || !password) {
      console.log('Missing username or password');
      return res.status(400).json({ message: 'Username and password are required' });
    }

    // Check if user exists
    const user = await User.findOne({ username });
    if (!user) {
      console.log('User not found:', username);
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    console.log('User found, comparing password...');

    // Check password
    try {
      const isMatch = await user.comparePassword(password);
      if (!isMatch) {
        console.log('Invalid password for user:', username);
        return res.status(401).json({ message: 'Invalid username or password' });
      }
    } catch (error) {
      console.error('Password comparison error:', error);
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    console.log('Login successful for:', username);

    // Create JWT token
    const token = jwt.sign(
      { userId: user._id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: {
        id: user._id,
        username: user.username
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const getCurrentUser = async (req, res) => {
  try {
    console.log('Getting current user for:', req.user); // Debug log
    const user = await User.findById(req.user.userId).select('-password');
    if (!user) {
      console.log('User not found for ID:', req.user.userId); // Debug log
      return res.status(404).json({ message: 'User not found' });
    }
    console.log('Found user:', user); // Debug log
    res.json(user);
  } catch (err) {
    console.error('Get current user error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

export const updateBudget = async (req, res) => {
  try {
    const userId = req.user.userId; // Get user ID from authenticated request
    const { budget } = req.body;

    if (typeof budget !== 'number' || budget < 0) {
      return res.status(400).json({ message: 'Invalid budget amount' });
    }

    const user = await User.findByIdAndUpdate(
      userId,
      { $set: { budget: budget } },
      { new: true, select: '-password' } // Return the updated user, excluding password
    );

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json(user); // Send back the updated user object

  } catch (err) {
    console.error('Update budget error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// New controller to get category data (budgets and custom categories)
export const getCategoryData = async (req, res) => {
  try {
    const userId = req.user.userId;
    const user = await User.findById(userId).select('categoryBudgets customCategories');

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    res.json({ categoryBudgets: user.categoryBudgets, customCategories: user.customCategories });

  } catch (err) {
    console.error('Get category data error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// New controller to update budget for a specific category
export const updateCategoryBudget = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { category, amount } = req.body;

    if (!category || typeof amount !== 'number' || amount < 0) {
      return res.status(400).json({ message: 'Category and a valid amount are required' });
    }

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Find if the category already exists in categoryBudgets
    const existingBudget = user.categoryBudgets.find(b => b.category === category);

    if (existingBudget) {
      // Update existing budget
      existingBudget.amount = amount;
    } else {
      // Add new category budget
      user.categoryBudgets.push({ category, amount });
    }

    await user.save();

    // Respond with the updated user data (excluding password)
    const updatedUser = await User.findById(userId).select('-password');
    res.json(updatedUser); // Sending back the updated user object

  } catch (err) {
    console.error('Update category budget error:', err);
    res.status(500).json({ message: 'Server error' });
  }
};

// New controller to add a custom category
export const addCustomCategory = async (req, res) => {
  try {
    const userId = req.user.userId;
    const { category } = req.body;

    if (!category || typeof category !== 'string' || category.trim() === '') {
      return res.status(400).json({ message: 'A valid category name is required' });
    }

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Check if category already exists (either default or custom)
    const defaultCategories = ['Food', 'Transport', 'Housing', 'Utilities', 'Entertainment', 'Other']; // Define default categories or fetch from a config if available
    if (defaultCategories.includes(category) || user.customCategories.includes(category)) {
        return res.status(400).json({ message: 'Category already exists' });
    }

    user.customCategories.push(category);
    await user.save();

    // Respond with the updated user data (excluding password)
    const updatedUser = await User.findById(userId).select('-password');
    res.json(updatedUser); // Sending back the updated user object

  } catch (err) {
    console.error('Add custom category error:', err);
    res.status(500).json({ message: 'Server error' });
  }
}; 