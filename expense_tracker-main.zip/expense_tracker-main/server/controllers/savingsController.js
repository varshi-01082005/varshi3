import SavingsGoal from '../models/SavingsGoal.js';

export const createSavingsGoal = async (req, res) => {
  try {
    // Get user ID from the authenticated request (set by auth middleware)
    const userId = req.user.userId;

    // Get savings goal data from the request body
    const { targetAmount, currentAmount, deadline } = req.body;

    // Basic validation
    if (!targetAmount) {
      return res.status(400).json({ message: 'Target amount is required' });
    }

    // Create a new savings goal instance
    const savingsGoal = new SavingsGoal({
      user: userId,
      targetAmount,
      currentAmount: currentAmount || 0, // Default to 0 if not provided
      deadline,
    });

    // Save the savings goal to the database
    await savingsGoal.save();

    res.status(201).json(savingsGoal); // Respond with the created savings goal

  } catch (err) {
    console.error('Error creating savings goal:', err);
    // Handle potential validation errors
    if (err.name === 'ValidationError') {
      return res.status(400).json({ message: err.message });
    }
    res.status(500).json({ message: 'Server error' });
  }
}; 