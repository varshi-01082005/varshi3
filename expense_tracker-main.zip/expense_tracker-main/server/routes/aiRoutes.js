import express from 'express';
import auth from '../middleware/auth.js';

const router = express.Router();

// Protected routes
router.use(auth);

// Get AI insights
router.get('/insights', async (req, res) => {
  try {
    res.json({ message: 'AI insights route working' });
  } catch (err) {
    res.status(500).json({ message: 'Server error' });
  }
});

export default router; 