import express from 'express';
import Expense from '../models/Expense.js';
import User from '../models/User.js';
import auth from '../middleware/auth.js';

const router = express.Router();

// Get all expenses for the authenticated user
router.get('/', auth, async (req, res) => {
  try {
    const expenses = await Expense.find({ user: req.user.userId })
      .sort({ date: -1 });
    res.json(expenses);
  } catch (err) {
    console.error('Error fetching expenses:', err);
    res.status(500).json({ message: 'Error fetching expenses' });
  }
});

// Add new expense
router.post('/', auth, async (req, res) => {
  try {
    const { description, amount, category, date } = req.body;
    
    const expense = new Expense({
      description,
      amount,
      category,
      date: date || new Date(),
      user: req.user.userId
    });

    await expense.save();

    // Add expense to user's expenses array
    await User.findByIdAndUpdate(
      req.user.userId,
      { $push: { expenses: expense._id } }
    );

    res.status(201).json(expense);
  } catch (err) {
    console.error('Error adding expense:', err);
    res.status(500).json({ message: 'Error adding expense' });
  }
});

// Update expense
router.put('/:id', auth, async (req, res) => {
  try {
    const expense = await Expense.findOne({
      _id: req.params.id,
      user: req.user.userId
    });

    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }

    const { description, amount, category, date } = req.body;
    expense.description = description;
    expense.amount = amount;
    expense.category = category;
    expense.date = date;

    await expense.save();
    res.json(expense);
  } catch (err) {
    console.error('Error updating expense:', err);
    res.status(500).json({ message: 'Error updating expense' });
  }
});

// Delete expense
router.delete('/:id', auth, async (req, res) => {
  try {
    const expense = await Expense.findOneAndDelete({
      _id: req.params.id,
      user: req.user.userId
    });

    if (!expense) {
      return res.status(404).json({ message: 'Expense not found' });
    }

    // Remove expense from user's expenses array
    await User.findByIdAndUpdate(
      req.user.userId,
      { $pull: { expenses: expense._id } }
    );

    res.json({ message: 'Expense deleted successfully' });
  } catch (err) {
    console.error('Error deleting expense:', err);
    res.status(500).json({ message: 'Error deleting expense' });
  }
});

export default router; 