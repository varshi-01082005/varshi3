import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import Expense from '../models/Expense.js';
import auth from '../middleware/auth.js';
import { register, login, getCurrentUser, updateBudget, getCategoryData, updateCategoryBudget, addCustomCategory } from '../controllers/authController.js';

const router = express.Router();

// Public routes
router.post('/register', async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    // Check if user exists
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: 'Username already exists' });
    }

    // Create new user
    const user = new User({
      username,
      password
    });

    await user.save();

    // Create token
    const token = jwt.sign(
      { userId: user._id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({
      token,
      user: user.getPublicProfile()
    });
  } catch (err) {
    console.error('Register error:', err);
    if (err.name === 'ValidationError') {
      return res.status(400).json({ message: err.message });
    }
    res.status(500).json({ message: 'Server error during registration' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    // Validate input
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    // Find user
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid username or password' });
    }

    // Create token
    const token = jwt.sign(
      { userId: user._id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: user.getPublicProfile()
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Server error during login' });
  }
});

// Protected routes
router.get('/me', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user.getPublicProfile());
  } catch (err) {
    console.error('Get user error:', err);
    res.status(500).json({ message: 'Server error while fetching user' });
  }
});

// Add new routes for category data and budget
router.get('/categories', auth, getCategoryData);
router.put('/categories/budget', auth, updateCategoryBudget);
router.post('/categories/custom', auth, addCustomCategory);

// Create admin user
router.post('/create-admin', async (req, res) => {
  try {
    const username = 'admin';
    const password = 'admin123';
    console.log('Creating admin user:', username);

    // Remove any existing admin user
    await User.deleteMany({ username });

    // Create new admin user
    const adminUser = new User({
      username,
      password,
      role: 'admin'
    });

    await adminUser.save();
    console.log('Admin user created successfully');
    
    res.json({ 
      success: true, 
      message: 'Admin user created successfully',
      credentials: {
        username,
        password
      }
    });
  } catch (err) {
    console.error('Create admin user error:', err);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to create admin user',
      error: err.message 
    });
  }
});

// Create test user
router.post('/create-test-user', async (req, res) => {
  try {
    const username = 'test';
    const password = 'test123';

    // Remove existing test user
    await User.deleteMany({ username });

    // Create new test user
    const testUser = new User({
      username,
      password
    });

    await testUser.save();
    console.log('Test user created successfully');

    res.json({
      success: true,
      message: 'Test user created successfully',
      credentials: { username, password }
    });
  } catch (err) {
    console.error('Create test user error:', err);
    res.status(500).json({
      success: false,
      message: 'Failed to create test user',
      error: err.message
    });
  }
});

// Create default user (always available)
router.post('/create-default', async (req, res) => {
  try {
    const email = 'user@example.com';
    const password = 'password123';

    // Remove any existing default user
    await User.deleteMany({ email });

    // Create new default user with pre-hashed password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const defaultUser = new User({
      email,
      password: hashedPassword,
      role: 'user'
    });

    await defaultUser.save();
    console.log('Default user created successfully');
    
    res.json({ 
      success: true, 
      message: 'Default user created successfully',
      credentials: {
        email,
        password
      }
    });
  } catch (err) {
    console.error('Create default user error:', err);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to create default user',
      error: err.message 
    });
  }
});

// Create verified test user
router.post('/create-verified-user', async (req, res) => {
  try {
    const { email = 'verified@example.com', password = 'Test@123' } = req.body;
    
    // Check if user already exists
    let user = await User.findOne({ email });
    
    if (user) {
      // Update existing user
      user.password = await bcrypt.hash(password, 10);
      user.isVerified = true;
      await user.save();
    } else {
      // Create new user
      user = new User({
        email,
        password: await bcrypt.hash(password, 10),
        username: email.split('@')[0], // Use part before @ as username
        isVerified: true
      });
      await user.save();
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      success: true,
      message: 'Verified user created/updated successfully',
      token,
      user: {
        id: user._id,
        email: user.email,
        username: user.username,
        isVerified: user.isVerified
      }
    });
  } catch (error) {
    console.error('Error creating verified user:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create verified user',
      error: error.message
    });
  }
});

// Create test user with sample expenses
router.post('/create-test', async (req, res) => {
  try {
    const username = 'test';
    const password = 'test123';
    console.log('Creating test user:', username);

    // Remove any existing test user and their expenses
    await User.deleteMany({ username });
    await Expense.deleteMany({ username });

    // Create new test user
    const testUser = new User({
      username,
      password,
      role: 'user'
    });

    await testUser.save();
    console.log('Test user created successfully');

    // Create sample expenses
    const sampleExpenses = [
      {
        description: 'Grocery Shopping',
        amount: 150.50,
        category: 'Food',
        date: new Date(),
        user: testUser._id
      },
      {
        description: 'Monthly Rent',
        amount: 1200,
        category: 'Housing',
        date: new Date(),
        user: testUser._id
      },
      {
        description: 'Electric Bill',
        amount: 85.75,
        category: 'Utilities',
        date: new Date(),
        user: testUser._id
      }
    ];

    await Expense.insertMany(sampleExpenses);
    console.log('Sample expenses created successfully');
    
    res.json({ 
      success: true, 
      message: 'Test user and sample expenses created successfully',
      credentials: {
        username,
        password
      }
    });
  } catch (err) {
    console.error('Create test user error:', err);
    res.status(500).json({ 
      success: false, 
      message: 'Failed to create test user',
      error: err.message 
    });
  }
});

export default router; 