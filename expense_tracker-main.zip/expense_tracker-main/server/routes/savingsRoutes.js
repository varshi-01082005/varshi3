import express from 'express';
import auth from '../middleware/auth.js';
import { createSavingsGoal } from '../controllers/savingsController.js';

const router = express.Router();

// @route   POST /api/savings
// @desc    Create a new savings goal
// @access  Private
router.post('/', auth, createSavingsGoal);

export default router; 