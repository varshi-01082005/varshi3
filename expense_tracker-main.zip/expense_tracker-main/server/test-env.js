import dotenv from 'dotenv';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

// Get the directory name of the current module
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

console.log('Current directory:', __dirname);
console.log('Looking for .env file at:', join(__dirname, '.env'));

// Load environment variables
dotenv.config();

console.log('\nEnvironment Variables:');
console.log('MONGODB_URI:', process.env.MONGODB_URI ? '✓ Set' : '✗ Missing');
console.log('GROQ_API_KEY:', process.env.GROQ_API_KEY ? '✓ Set' : '✗ Missing');
console.log('JWT_SECRET:', process.env.JWT_SECRET ? '✓ Set' : '✗ Missing');
console.log('PORT:', process.env.PORT || 5000);

// Check required variables
const requiredEnvVars = ['MONGODB_URI', 'JWT_SECRET', 'GROQ_API_KEY'];
const missingEnvVars = requiredEnvVars.filter(envVar => !process.env[envVar]);

if (missingEnvVars.length > 0) {
  console.error('Missing required environment variables:', missingEnvVars);
  process.exit(1);
}

console.log('All environment variables loaded successfully:');
console.log('MONGODB_URI:', process.env.MONGODB_URI ? '✓' : '✗');
console.log('JWT_SECRET:', process.env.JWT_SECRET ? '✓' : '✗');
console.log('GROQ_API_KEY:', process.env.GROQ_API_KEY ? '✓' : '✗'); 