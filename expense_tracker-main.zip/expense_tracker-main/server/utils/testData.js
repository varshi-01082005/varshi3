import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import Expense from '../models/Expense.js';

export const createTestUser = async (username, password) => {
  try {
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create user
    const user = new User({
      username,
      password: hashedPassword
    });

    await user.save();
    console.log('Test user created:', username);

    // Create sample expenses
    const sampleExpenses = [
      {
        user: user._id,
        amount: 50.00,
        category: 'Food',
        description: 'Grocery shopping',
        date: new Date()
      },
      {
        user: user._id,
        amount: 30.00,
        category: 'Transportation',
        description: 'Bus fare',
        date: new Date()
      },
      {
        user: user._id,
        amount: 100.00,
        category: 'Entertainment',
        description: 'Movie tickets',
        date: new Date()
      }
    ];

    await Expense.insertMany(sampleExpenses);
    console.log('Sample expenses created for:', username);

    return user;
  } catch (error) {
    console.error('Error creating test user:', error);
    throw error;
  }
}; 