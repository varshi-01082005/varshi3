import Expense from '../models/Expense.js';

// Add a new expense
export const addExpense = async (req, res) => {
  try {
    const { amount, description, category, date, isRecurring, recurringDetails, tags, notes } = req.body;
    
    // Validate required fields
    if (!amount || !description || !category) {
      return res.status(400).json({ 
        success: false, 
        error: 'Please provide all required fields' 
      });
    }

    // Create new expense
    const expense = new Expense({
      user: req.user.id,
      amount: parseFloat(amount),
      description,
      category,
      date: date || new Date(),
      isRecurring,
      recurringDetails,
      tags,
      notes
    });

    // Save expense
    await expense.save();

    res.status(201).json({
      success: true,
      data: expense
    });
  } catch (error) {
    console.error('Error adding expense:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to add expense'
    });
  }
};

// Get all expenses for a user
export const getExpenses = async (req, res) => {
  try {
    const { startDate, endDate, category, sortBy = 'date', sortOrder = 'desc' } = req.query;
    
    // Build query
    const query = { user: req.user.id };
    if (startDate && endDate) {
      query.date = { $gte: new Date(startDate), $lte: new Date(endDate) };
    }
    if (category) {
      query.category = category;
    }

    // Build sort options
    const sortOptions = {};
    sortOptions[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Get expenses
    const expenses = await Expense.find(query)
      .sort(sortOptions)
      .lean();

    // Get total amount
    const total = await Expense.getTotalExpenses(req.user.id, startDate, endDate);

    // Get category breakdown
    const categoryBreakdown = await Expense.getExpensesByCategory(req.user.id, startDate, endDate);

    res.status(200).json({
      success: true,
      count: expenses.length,
      total,
      categoryBreakdown,
      data: expenses
    });
  } catch (error) {
    console.error('Error getting expenses:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to get expenses'
    });
  }
};

// Get single expense
export const getExpense = async (req, res) => {
  try {
    const expense = await Expense.findOne({
      _id: req.params.id,
      user: req.user.id
    });

    if (!expense) {
      return res.status(404).json({
        success: false,
        error: 'Expense not found'
      });
    }

    res.status(200).json({
      success: true,
      data: expense
    });
  } catch (error) {
    console.error('Error getting expense:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to get expense'
    });
  }
};

// Update expense
export const updateExpense = async (req, res) => {
  try {
    const { amount, description, category, date, isRecurring, recurringDetails, tags, notes } = req.body;
    
    // Find expense
    let expense = await Expense.findOne({
      _id: req.params.id,
      user: req.user.id
    });

    if (!expense) {
      return res.status(404).json({
        success: false,
        error: 'Expense not found'
      });
    }

    // Update fields
    if (amount) expense.amount = parseFloat(amount);
    if (description) expense.description = description;
    if (category) expense.category = category;
    if (date) expense.date = new Date(date);
    if (typeof isRecurring !== 'undefined') expense.isRecurring = isRecurring;
    if (recurringDetails) expense.recurringDetails = recurringDetails;
    if (tags) expense.tags = tags;
    if (notes) expense.notes = notes;

    // Save changes
    await expense.save();

    res.status(200).json({
      success: true,
      data: expense
    });
  } catch (error) {
    console.error('Error updating expense:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to update expense'
    });
  }
};

// Delete expense
export const deleteExpense = async (req, res) => {
  try {
    const expense = await Expense.findOneAndDelete({
      _id: req.params.id,
      user: req.user.id
    });

    if (!expense) {
      return res.status(404).json({
        success: false,
        error: 'Expense not found'
      });
    }

    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    console.error('Error deleting expense:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to delete expense'
    });
  }
};

// Get expense statistics
export const getExpenseStats = async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    // Get total expenses
    const total = await Expense.getTotalExpenses(req.user.id, startDate, endDate);
    
    // Get category breakdown
    const categoryBreakdown = await Expense.getExpensesByCategory(req.user.id, startDate, endDate);
    
    // Get monthly trend
    const monthlyTrend = await Expense.aggregate([
      {
        $match: {
          user: req.user.id,
          ...(startDate && endDate ? {
            date: { $gte: new Date(startDate), $lte: new Date(endDate) }
          } : {})
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$date' },
            month: { $month: '$date' }
          },
          total: { $sum: '$amount' }
        }
      },
      {
        $sort: { '_id.year': 1, '_id.month': 1 }
      }
    ]);

    res.status(200).json({
      success: true,
      data: {
        total,
        categoryBreakdown,
        monthlyTrend
      }
    });
  } catch (error) {
    console.error('Error getting expense statistics:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Failed to get expense statistics'
    });
  }
}; 