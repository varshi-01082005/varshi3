// LOAD ENV VARS FIRST - CRITICAL FIX
import dotenv from 'dotenv';
dotenv.config();

import OpenAI from 'openai';
import { Groq } from 'groq-sdk';
import Expense from '../models/Expense.js';

// Debug logging
console.log('AI Controller Environment Check:');
console.log('GROQ_API_KEY exists:', !!process.env.GROQ_API_KEY);
console.log('OPENAI_API_KEY exists:', !!process.env.OPENAI_API_KEY);

// OpenAI instance - will be initialized when needed
let openai;

// Initialize Groq with proper error handling
let groq;
try {
  if (!process.env.GROQ_API_KEY) {
    throw new Error('GROQ_API_KEY is not set in environment variables');
  }
  
  groq = new Groq({
    apiKey: process.env.GROQ_API_KEY
  });
  console.log('Groq initialized successfully');
} catch (error) {
  console.error('Groq initialization failed:', error.message);
  // Don't crash the entire app, just log the error
}

// Function to initialize OpenAI (called when needed)
const initializeOpenAI = () => {
  if (openai) return openai; // Already initialized
  
  if (!process.env.OPENAI_API_KEY) {
    throw new Error('OPENAI_API_KEY is not set in environment variables');
  }
  
  openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });
  
  console.log('OpenAI initialized successfully');
  return openai;
};

// Test OpenAI connection
const testOpenAI = async () => {
  try {
    const openaiClient = initializeOpenAI();
    const completion = await openaiClient.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant that categorizes expenses."
        },
        {
          role: "user",
          content: "Test connection"
        }
      ],
      max_tokens: 5
    });
    console.log("OpenAI API connection successful!");
    return true;
  } catch (error) {
    console.error("OpenAI API connection failed:", error.message);
    return false;
  }
};

// Export function to test connection when app is ready
export const testConnection = testOpenAI;

export const categorize = async (req, res) => {
  try {
    const openaiClient = initializeOpenAI();
    
    const { description } = req.body;
    if (!description) {
      return res.status(400).json({ error: 'Description is required' });
    }

    const prompt = `Categorize the following expense description into a simple category like Food, Travel, Shopping, Entertainment, Bills, Healthcare, Education, or Other.\nDescription: ${description}\nCategory:`;
    
    const completion = await openaiClient.chat.completions.create({
      model: "gpt-3.5-turbo",
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant that categorizes expenses into simple categories."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.2,
      max_tokens: 10
    });

    const category = completion.choices[0].message.content.trim();
    console.log(`Categorized "${description}" as "${category}"`);
    res.json({ category });
  } catch (error) {
    console.error('AI Categorization error:', error);
    
    if (error.message.includes('OPENAI_API_KEY')) {
      return res.status(500).json({ 
        error: 'OpenAI service is not properly configured',
        details: 'Please check your environment variables'
      });
    }
    
    res.status(500).json({ 
      error: 'Failed to categorize expense',
      details: error.message 
    });
  }
}

// Initialize Groq
const initializeGroq = () => {
  if (!process.env.GROQ_API_KEY) {
    throw new Error('GROQ_API_KEY is not set in environment variables');
  }
  return new Groq({
    apiKey: process.env.GROQ_API_KEY
  });
};

// Get AI insights for user's expenses
export const getInsights = async (req, res) => {
  try {
    const groq = initializeGroq();
    
    const expenses = await Expense.find({ user: req.user.id })
      .sort({ date: -1 })
      .limit(50);

    if (expenses.length === 0) {
      return res.json({
        insights: "No expenses found. Start adding expenses to get AI insights!",
        recommendations: []
      });
    }

    // Prepare data for AI analysis
    const expenseData = expenses.map(exp => ({
      amount: exp.amount,
      category: exp.category,
      description: exp.description,
      date: exp.date
    }));

    // Calculate basic statistics
    const totalSpent = expenses.reduce((sum, exp) => sum + exp.amount, 0);
    const categoryTotals = expenses.reduce((acc, exp) => {
      acc[exp.category] = (acc[exp.category] || 0) + exp.amount;
      return acc;
    }, {});

    // Generate prompt for GroqAI
    const prompt = `Analyze this expense data and provide insights and recommendations:
    Total spent: $${totalSpent}
    Category breakdown: ${JSON.stringify(categoryTotals)}
    Recent expenses: ${JSON.stringify(expenseData.slice(0, 5))}
    
    Please provide:
    1. A brief analysis of spending patterns
    2. 3 specific recommendations for better expense management
    3. Potential areas for cost savings`;

    // Get AI response
    const completion = await groq.chat.completions.create({
      messages: [{ role: "user", content: prompt }],
      model: "mixtral-8x7b-32768",
      temperature: 0.7,
      max_tokens: 1024,
    });

    const aiResponse = completion.choices[0]?.message?.content || "Unable to generate insights at this time.";

    // Parse the AI response into structured format
    const insights = aiResponse.split('\n\n')[0];
    const recommendations = aiResponse
      .split('\n\n')[1]
      ?.split('\n')
      .filter(line => line.trim().startsWith('-') || line.trim().match(/^\d+\./))
      .map(line => line.replace(/^[-0-9.]+\s*/, '').trim())
      .filter(Boolean) || [];

    res.json({
      insights,
      recommendations
    });
  } catch (error) {
    console.error('AI insights error:', error);
    res.status(500).json({ error: 'Failed to generate AI insights' });
  }
};

// Get expense predictions
export const getPredictions = async (req, res) => {
  try {
    // Check if Groq is available
    if (!groq) {
      return res.status(500).json({ 
        error: 'AI service is not available',
        details: 'GROQ_API_KEY is not configured properly'
      });
    }

    const expenses = await Expense.find({ user: req.user.id })
      .sort({ date: -1 })
      .limit(30);

    if (expenses.length === 0) {
      return res.json({
        prediction: "Not enough data to make predictions. Add more expenses!",
        confidence: 0
      });
    }

    // Prepare data for prediction
    const expenseData = expenses.map(exp => ({
      amount: exp.amount,
      category: exp.category,
      date: exp.date
    }));

    // Generate prompt for GroqAI
    const prompt = `Based on this expense history, predict the likely spending pattern for the next month:
    ${JSON.stringify(expenseData)}
    
    Please provide:
    1. A prediction of total spending for next month
    2. Expected spending by category
    3. Confidence level in the prediction (0-100%)`;

    // Get AI response
    const completion = await groq.chat.completions.create({
      messages: [{ role: "user", content: prompt }],
      model: "mixtral-8x7b-32768",
      temperature: 0.7,
      max_tokens: 1024,
    });

    const aiResponse = completion.choices[0]?.message?.content || "Unable to generate predictions at this time.";

    res.json({
      prediction: aiResponse,
      confidence: 75 // This would ideally come from the AI response
    });
  } catch (err) {
    console.error('AI predictions error:', err);
    res.status(500).json({ error: 'Failed to generate predictions' });
  }
};