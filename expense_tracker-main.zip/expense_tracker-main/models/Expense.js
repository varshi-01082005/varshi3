import mongoose from 'mongoose';

const ExpenseSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    index: true
  },
  amount: {
    type: Number,
    required: [true, 'Amount is required'],
    min: [0, 'Amount cannot be negative'],
    validate: {
      validator: function(v) {
        return v > 0;
      },
      message: 'Amount must be greater than 0'
    }
  },
  description: {
    type: String,
    required: [true, 'Description is required'],
    trim: true,
    minlength: [3, 'Description must be at least 3 characters long'],
    maxlength: [200, 'Description cannot exceed 200 characters']
  },
  category: {
    type: String,
    required: [true, 'Category is required'],
    enum: {
      values: ['Food', 'Travel', 'Shopping', 'Entertainment', 'Bills', 'Healthcare', 'Education', 'Other'],
      message: '{VALUE} is not a valid category'
    },
    index: true
  },
  date: {
    type: Date,
    required: [true, 'Date is required'],
    default: Date.now,
    index: true
  },
  isRecurring: {
    type: Boolean,
    default: false
  },
  recurringDetails: {
    frequency: {
      type: String,
      enum: ['daily', 'weekly', 'monthly', 'yearly'],
      default: 'monthly'
    },
    nextDueDate: Date,
    endDate: Date
  },
  tags: [{
    type: String,
    trim: true
  }],
  receipt: {
    url: String,
    filename: String
  },
  notes: {
    type: String,
    trim: true,
    maxlength: [500, 'Notes cannot exceed 500 characters']
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

// Indexes for common queries
ExpenseSchema.index({ user: 1, date: -1 });
ExpenseSchema.index({ user: 1, category: 1, date: -1 });
ExpenseSchema.index({ user: 1, amount: -1 });

// Virtual for formatted date
ExpenseSchema.virtual('formattedDate').get(function() {
  return this.date.toLocaleDateString();
});

// Virtual for formatted amount
ExpenseSchema.virtual('formattedAmount').get(function() {
  return `$${this.amount.toFixed(2)}`;
});

// Pre-save middleware for data validation
ExpenseSchema.pre('save', function(next) {
  // Ensure amount is a number and positive
  if (typeof this.amount !== 'number' || this.amount <= 0) {
    next(new Error('Invalid amount'));
  }
  
  // Ensure date is valid
  if (!(this.date instanceof Date) || isNaN(this.date)) {
    next(new Error('Invalid date'));
  }
  
  next();
});

// Static method to get total expenses for a user
ExpenseSchema.statics.getTotalExpenses = async function(userId, startDate, endDate) {
  const query = { user: userId };
  if (startDate && endDate) {
    query.date = { $gte: startDate, $lte: endDate };
  }
  
  const result = await this.aggregate([
    { $match: query },
    { $group: { _id: null, total: { $sum: '$amount' } } }
  ]);
  
  return result[0]?.total || 0;
};

// Static method to get expenses by category
ExpenseSchema.statics.getExpensesByCategory = async function(userId, startDate, endDate) {
  const query = { user: userId };
  if (startDate && endDate) {
    query.date = { $gte: startDate, $lte: endDate };
  }
  
  return this.aggregate([
    { $match: query },
    { $group: { _id: '$category', total: { $sum: '$amount' } } },
    { $sort: { total: -1 } }
  ]);
};

// Method to check if expense is overdue (for recurring expenses)
ExpenseSchema.methods.isOverdue = function() {
  if (!this.isRecurring || !this.recurringDetails.nextDueDate) {
    return false;
  }
  return new Date() > this.recurringDetails.nextDueDate;
};

export default mongoose.model('Expense', ExpenseSchema); 